<div class="module <?php echo $style; ?>">
	<div>
		<div class="deepest">
		
			<?php echo $badge; ?>
			<?php if ($showtitle) echo $title; ?>
			<?php echo $content; ?>
			
		</div>
	</div>
</div>